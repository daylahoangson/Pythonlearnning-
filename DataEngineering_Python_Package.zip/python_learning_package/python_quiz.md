
# Python Basic to Intermediate Quiz

## Part 1: Multiple Choice
1. What is the output of `len([1,2,3])`?
   - A. 2
   - B. 3
   - C. Error

2. Which of the following is a valid way to create a dictionary?
   - A. `dict = {"a":1, "b":2}`
   - B. `dict = ("a":1, "b":2)`
   - C. `dict = [("a",1), ("b",2)]`

3. What does `df.groupby("col").sum()` do in pandas?

## Part 2: Coding
1. Write a function to return the factorial of a number.
2. Given a list of numbers, remove all duplicates and return sorted list.
3. Fetch data from an API endpoint and print JSON content.

