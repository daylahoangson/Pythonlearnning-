
import requests
import pandas as pd
import psycopg2

def fetch_data():
    url = "https://api.covid19api.com/summary"
    response = requests.get(url)
    data = response.json()["Countries"]
    return pd.DataFrame(data)

def load_to_postgres(df):
    conn = psycopg2.connect(
        dbname="etl_db", user="postgres", password="postgres", host="db"
    )
    cursor = conn.cursor()
    for _, row in df.iterrows():
        cursor.execute("INSERT INTO covid_data (Country, TotalConfirmed) VALUES (%s, %s)", (row["Country"], row["TotalConfirmed"]))
    conn.commit()
    cursor.close()
    conn.close()

if __name__ == "__main__":
    df = fetch_data()
    load_to_postgres(df)
